﻿namespace Assets.scripts.Upgrade
{
	public enum ItemType
	{
		STAT_UPGRADE,
		CLASSIC_UPGRADE,
		RARE_UPGRADE,
		EPIC_UPGRADE
	}
}