﻿namespace Assets.scripts.Actor.PlayerClasses.Base
{
	public enum ClassId
	{
		Default,
		Flu,
		CommonCold
	}
}
