﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Assets.scripts.Actor.MonsterClasses.Base;
using Assets.scripts.AI;

namespace Assets.scripts.Actor.MonsterClasses
{
	public abstract class BossTemplate : MonsterTemplate
	{

	}
}
