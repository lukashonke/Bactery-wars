﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Assets.scripts.AI
{
	public enum AIState
	{
		IDLE,
		ACTIVE,
		ATTACKING
	}
}
