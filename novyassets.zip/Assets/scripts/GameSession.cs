﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Assets.scripts
{
	public class GameSession
	{
		public static string className = "CommonCold";
		public static string difficulty = "Easy";
		public static string gameType = "Normal";
		public static string profileName = "Lukas";
		public static bool skipTutorial = false;


		public static bool repairMap = true;

		public static bool arenaMode = true;
	}
}
