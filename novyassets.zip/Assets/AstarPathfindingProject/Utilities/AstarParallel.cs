#if NETFX_CORE && !UNITY_EDITOR
//using Thread = MarkerMetro.Unity.WinLegacy.Threading.Thread;
//using ParameterizedThreadStart = MarkerMetro.Unity.WinLegacy.Threading.ParameterizedThreadStart;
#endif

using UnityEngine;
using System.Collections;
using System.Threading;

namespace Pathfinding.Threading {
}